export default async (req) => {
  const headers = { "Content-Type": "application/json" };
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "Method not allowed." }), { status: 405, headers });
  try {
    const { message } = await req.json();
    if (!message || typeof message !== "string") return new Response(JSON.stringify({ error: "Please enter a message." }), { status: 400, headers });
    const apiKey = Netlify.env.get("GEMINI_API_KEY");
    if (!apiKey) return new Response(JSON.stringify({ error: "Gemini API key is not configured on Netlify." }), { status: 500, headers });
    const resultResponse = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({ contents: [{ parts: [{ text: message }] }] })
    });
    const result = await resultResponse.json();
    if (!resultResponse.ok) return new Response(JSON.stringify({ error: result.error?.message || "Gemini could not process the request." }), { status: resultResponse.status, headers });
    const answer = result.candidates?.[0]?.content?.parts?.map(part => part.text || "").join("") || "";
    if (!answer) return new Response(JSON.stringify({ error: "Gemini returned an empty response." }), { status: 502, headers });
    return new Response(JSON.stringify({ answer }), { status: 200, headers });
  } catch {
    return new Response(JSON.stringify({ error: "The AI service could not respond. Please try again." }), { status: 500, headers });
  }
};
